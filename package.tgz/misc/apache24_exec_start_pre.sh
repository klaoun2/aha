#!/bin/bash

echo "pre-start"
HttpdConf="/usr/local/etc/apache24/conf/httpd24.conf"

/usr/bin/mkdir -p /usr/local/etc/apache24/sites-enabled || true
/usr/bin/chown root:root /usr/local/etc/apache24/sites-enabled || true
/usr/bin/chmod 755 /usr/local/etc/apache24/sites-enabled || true

/usr/bin/mkdir -p /var/log/httpd /run/httpd || true
/usr/bin/rm -f /run/httpd/user-cgisock.* || true

if [ ! -s ${HttpdConf} ]; then
    logger -p err -t $0 "${HttpdConf} is empty."
fi

/usr/bin/mknod /run/apache24-access_log p || true
/usr/bin/chmod 600 /run/apache24-access_log

/usr/bin/mknod /run/apache24-error_log p || true
/usr/bin/chmod 600 /run/apache24-error_log

echo "Start Apache Server ....."
